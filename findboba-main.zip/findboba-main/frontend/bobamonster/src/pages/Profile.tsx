import React from 'react';

const ProfilePage: React.FC = () => {
    return (
        <div>
            <h1>Profile Page</h1>
            <p>Welcome to your profile!</p>
        </div>
    );
};

export default ProfilePage;


let points = 100; // Initial points

export const getUserPoints = () => points;

export const setUserPoints = (newPoints: number) => {
  points = newPoints;
};